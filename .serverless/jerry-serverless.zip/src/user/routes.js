const express = require('express');
const routers = express.Router({
    mergeParams: true
});

route.get('/', (req, res) => {
    res.status(200).json({});
});

module.exports = {
    routes
};